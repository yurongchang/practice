var english = require('./english.js');
var spanish = require('./spanish.js');

module.exports = {
    english: english,
    spanish: spanish
};